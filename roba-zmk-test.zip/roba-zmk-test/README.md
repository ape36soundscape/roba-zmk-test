# roBa ZMK Test (mona2-style)
Minimal ZMK setup to test roBa hardware.
